# GrayFox – File Converter

**Private, offline file conversion.** Free file tools that run entirely on your computer. Convert images losslessly, make Windows icons and, soon, work with PDFs. There's no server and no install, and your files never leave your PC.

![Home page](docs/home.png)

## Tools

| Tool | What it does | Status |
|---|---|---|
| [Convert images](convert.html) | PNG, WebP, JPEG, TIFF, BMP and GIF, with true lossless conversion | Ready |
| [Make icons](ico.html) | Windows `.ico` files with every size, padding, trim and an Explorer preview | Ready |
| Image tools | Resize, crop, compress, watermark, remove metadata | Planned |
| PDF tools | Merge, split, organize pages, images to PDF and back, watermark | Planned |

## Use it

**Offline:** download the repo as a ZIP (green **Code** button, then **Download ZIP**), unzip it, and double-click `index.html`. It opens in Edge or Chrome and works without internet. Keep the files together in one folder.

**Online:** with GitHub Pages enabled, open `https://<your-username>.github.io/grayfox/`. It still runs entirely in your browser.

## Convert images

![Converter](docs/convert.png)

- **Formats:** reads PNG, JPEG, WebP, TIFF, BMP, GIF, AVIF, ICO and SVG; saves PNG, WebP, JPEG, TIFF, BMP and GIF.
- **True lossless:** PNG, WebP (lossless mode), TIFF and BMP keep every pixel exactly, including semi-transparent ones. GIF is lossless for images with up to 256 colors.
- **Verified:** after converting, the tool reopens each new file and compares it with the original pixel by pixel. It shows "Identical pixels" only when they match.
- **Color profiles kept** for PNG, WebP, TIFF and JPEG, so photos from phones and cameras look the same after conversion.
- **Batch:** convert many files at once and download them as a ZIP.

### Why "lossless" here really means lossless

Browsers store images with "premultiplied alpha", which slightly changes semi-transparent pixels whenever a page reads or saves them through the usual canvas methods. Many online converters lose detail this way even in "lossless" mode. This tool reads pixels exactly through WebGL and writes PNG, WebP, TIFF, BMP and GIF with its own encoders, so nothing is altered. Every output was tested against independent decoders (libpng, libwebp, libtiff).

## Make icons

![Icon maker](docs/icons.png)

- Choose the sizes inside the `.ico` (16 to 256 px).
- Fit modes: fit, max, crop and scale.
- **Trim transparent edges** plus **padding** make a set of icons look equally big in Explorer.
- Preview icons as Windows shows them in every view, in dark or light mode.

**Set a folder icon:** keep the `.ico` somewhere permanent (for example inside the folder), then right-click the folder and choose **Properties > Customize > Change Icon**. If Windows keeps showing the old icon, press Win+R and run `ie4uinit.exe -show`.

## Limits

- Saving as AVIF and opening HEIC photos aren't supported yet.
- Animated GIF and WebP files are converted using their first frame.
- 16-bit images are reduced to 8-bit color.
- ICO files hold images up to 256 × 256, which is the largest size Windows uses.

## Project structure

Each tool is a single self-contained HTML file with no external libraries, so any page also works on its own.

```
index.html     Home page
convert.html   Image converter
ico.html       Icon maker
docs/          Screenshots for this README
```

## License

[MIT](LICENSE)
